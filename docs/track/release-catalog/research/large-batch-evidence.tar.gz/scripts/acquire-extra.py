import pathlib,json,urllib.request,hashlib,datetime,concurrent.futures
p=pathlib.Path('/tmp/am-133');out=pathlib.Path('/home/marek/Documents/Codex/am-large-batch-20261106');out.mkdir(parents=True,exist_ok=True)
rows=json.loads((p/'selection.json').read_text())[-1:];assert sum(r['selected_asset']['size'] for r in rows)<4*1024**3

def acquire(row):
 app=row['app'];a=row['selected_asset'];target=out/(app+'.AppImage');size=a['size'];h=hashlib.sha256();count=0
 try:
  assert (a.get('digest') or '').startswith('sha256:'),'missing published digest'
  if target.exists():
   with target.open('rb') as f:
    while b:=f.read(1024*1024):h.update(b);count+=len(b)
   assert count==size
  else:
   with urllib.request.urlopen(a['browser_download_url'],timeout=60) as response,target.open('wb') as f:
    assert response.status==200
    if response.headers.get('Content-Length'):assert int(response.headers['Content-Length'])==size
    while True:
     b=response.read(min(1024*1024,size-count+1))
     if not b:break
     count+=len(b);assert count<=size
     f.write(b);h.update(b)
  assert count==size
  digest=a.get('digest');assert digest and digest=='sha256:'+h.hexdigest(),'missing or mismatched published digest'
  receipt=dict(app=app,asset_id=a['id'],release_id=row['selected_release'],url=a['browser_download_url'],bytes=count,sha256=h.hexdigest(),published_digest=digest,observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='verified')
 except Exception as e:receipt=dict(app=app,status='failed',reason=str(e))
 (p/app/'payload-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(app,receipt['status'],receipt.get('reason',str(count)),flush=True)
 return receipt
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:receipts=list(pool.map(acquire,rows))
(p/'extra-payload.json').write_text(json.dumps(receipts,indent=2)+'\n')
