import subprocess,json,pathlib,datetime
p=pathlib.Path('/tmp/am-freshness-live')
def api(route):return json.loads(subprocess.check_output(['gh','api','repos/mareklangiewicz/AM/'+route]))
w=api('actions/workflows');a=api('actions/permissions');s=api('git/ref/heads/main-marek');c=api('git/ref/heads/release-catalog')
assert a['enabled']
assert [(x['id'],x['state']) for x in w['workflows'] if x['state']=='active']==[(398399199,'active')]
assert s['object']['sha']=='3ad023822c4df52e3f69874b21200899bf7d3e82'
assert c['object']['sha']=='a0fdd125558c4629a07c7edd0d7f6f7f96b1dcc1'
(p/'prechecks.json').write_text(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workflows':w,'permissions':a,'source':s,'catalog':c},indent=2)+'\n')
subprocess.run(['gh','workflow','run','catalog-collector.yml','--repo','mareklangiewicz/AM','--ref','main-marek','-f','approved_revision='+s['object']['sha'],'-f','manifest_sha256=1c550b882e9855a7a652e44516d88db95046641da92f4b6e34fd65b9a6da87b9','-f','previous_publication='+c['object']['sha']],check=True)
print('Dispatched once; prechecks retained.')
