import pathlib,subprocess,json,datetime
p=pathlib.Path('/tmp/am-cadence-diagnosis')
base='repos/mareklangiewicz/AM/'
def save(route,name):
 raw=subprocess.check_output(['gh','api',(base+route).rstrip('/')]);(p/name).write_bytes(raw);return json.loads(raw)
save('','repository.json');save('actions/workflows','workflows.json');save('actions/permissions','permissions.json')
save('git/ref/heads/main-marek','source-ref.json');save('git/ref/heads/release-catalog','catalog-ref.json');save('actions/variables','variables.json')
s=save('actions/workflows/catalog-schedule.yml/runs?per_page=100','schedule-runs.json')
c=save('actions/workflows/catalog-collector.yml/runs?per_page=100','collector-runs.json')
for r in s['workflow_runs']:
 save(f'actions/runs/{r["id"]}/jobs?filter=all&per_page=100',f'{r["id"]}-jobs.json')
 for label in ['created_at','run_started_at','updated_at']:assert label in r
save('contents/.github/workflows/catalog-schedule.yml?ref=main-marek','remote-schedule.json')
save('commits?sha=main-marek&path=.github/workflows/catalog-schedule.yml&per_page=20','schedule-history.json')
(p/'captured.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print(json.dumps({'schedule_count':s['total_count'],'schedule_runs':[{k:r[k] for k in ['id','event','status','conclusion','created_at','run_started_at','updated_at','head_sha','run_attempt']} for r in s['workflow_runs']],'collector_count':c['total_count']},indent=2))
