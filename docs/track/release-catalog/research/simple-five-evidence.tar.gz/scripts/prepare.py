import pathlib,json,hashlib,subprocess,os,re,sys,shutil
root=pathlib.Path('/home/marek/code/shell/AM');p=pathlib.Path('/home/marek/Documents/Codex/am-catalog-expansion-20261106/simple-five/evidence');sys.path.insert(0,str(root/'tools/recipe-reconstruction'))
from originals import Catalogue,Originals
cat=Catalogue(Originals(root),['bbffd15c19d01ef9124fbf99b5b9c41d2661ea22','bb53f3180ec92f862020f8bdccef0f6614015bae'])
b=p/'bin';b.mkdir(exist_ok=True);(b/'curl').write_text('#!/bin/sh\ncat "$RESPONSE"\n');(b/'curl').chmod(0o755)
rows=json.loads((p/'metadata.json').read_text());chosen=[]
for row in rows:
 if row['status']!='metadata-ready':continue
 app=row['app'];d=p/app;source=(root/row['provenance']['recipe']).read_text();m=cat.check(source)['matches'][0]
 assert cat.render(m['template'],m['parameters'])==source
 expr=m['parameters'][2]
 old=subprocess.run(['sh','-c',expr],env={**os.environ,'PATH':str(b)+':/usr/bin:/bin','RESPONSE':str(d/'releases.json')},capture_output=True,text=True,check=True,timeout=10).stdout.strip()
 releases=json.loads((d/'releases.json').read_text());matches=[(r,a) for r in releases for a in r['assets'] if a['browser_download_url']==old]
 row['old_selected_url']=old
 if len(matches)!=1 or not matches[0][1]['name'].lower().endswith('.appimage'):
  row.update(status='excluded',reason='exact original selector does not uniquely select direct AppImage');continue
 r,a=matches[0];row.update(selected_release=r['id'],selected_asset=a,prerelease=r['prerelease'])
 if not 0<a['size']<=400*1024*1024:row.update(status='excluded',reason='payload size cap');continue
 # Prefix/suffix fixed around numeric version, or exact invariant filename.
 name=a['name'];version=r['tag_name'].removeprefix('v')
 def escape(s):return ''.join('['+c+']' if c in '.+?(){}|^$*[]\\' else c for c in s)
 if version and version in name and re.fullmatch('[0-9]+(?:[.][0-9]+)*',version):
  left,right=name.split(version,1);pattern='^'+escape(left)+'[0-9]+([.][0-9]+)*'+escape(right)+'$'
 else:
  # Generalize only clear numeric filename version runs with fixed surrounding text.
  found=re.search(r'(?<=[_-])v?[0-9]+(?:[.][0-9]+){1,3}(?=[_-]|[.]AppImage$)',name)
  if found:pattern='^'+escape(name[:found.start()])+('v' if found.group().startswith('v') else '')+'[0-9]+([.][0-9]+)*'+escape(name[found.end():])+'$'
  else:pattern='^'+escape(name)+'$'
 row['pattern']=pattern;row['strip_no_sandbox']='s# --no-sandbox##g' in source
 row['status']='selected';chosen.append(row)
 if len(chosen)==5:break
(p/'selection.json').write_text(json.dumps(chosen,indent=2)+'\n');(p/'screening.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in chosen:print(r['app'],r['selected_asset']['name'],r['selected_asset']['size'],r['pattern'])
print('TOTAL',len(chosen),sum(r['selected_asset']['size'] for r in chosen))
