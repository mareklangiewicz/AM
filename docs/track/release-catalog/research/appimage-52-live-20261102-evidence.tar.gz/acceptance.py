import sys,json,hashlib,subprocess,zipfile,io,os
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools/catalog-collector'))
from delivery import unpack_artifact,verify_artifact,read_git_tree
from storage import validate
from consumer import lookup
from identity_batch import PAYLOAD
from migration_batch import REPORT,pipeline
from test_appimage_lifecycle import selector_script
D=Path('/tmp/am52-live'); D.mkdir(exist_ok=True)
meta=json.loads((D/'artifacts.json').read_bytes())
for a in meta['artifacts']:
 raw=(D/(str(a['id'])+'.zip')).read_bytes()
 assert 'sha256:'+hashlib.sha256(raw).hexdigest()==a['digest']
 if a['name'].startswith('restricted-catalog-'): files=unpack_artifact(raw)
 else:
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   assert z.namelist()==['publication.json']; pub=json.loads(z.read('publication.json'))
report=json.loads(files['report.json']); ctx=report['context']
rev='4e379050d5a71f6494e84308383a6c36ec6d47cf'; parent='9f4e356ec2d50260196748374b00efdda397d7f7'
assert ctx['approved_revision']==rev and ctx['sha']==rev and ctx['run_id']=='41442000508' and ctx['run_attempt']=='1' and ctx['previous_publication']==parent
repo=D/'catalog.git'
prior=read_git_tree(repo,parent)
manifest=Path('docs/track/release-catalog/design/staged-manifest.json').read_bytes()
tree=verify_artifact(files,ctx,manifest,rev,prior)
assert pub['parent']==parent and pub['source_revision']==rev
commit=pub['commit']
assert subprocess.check_output(['git','--git-dir='+str(repo),'show','-s','--format=%P',commit]).decode().strip()==parent
assert read_git_tree(repo,commit)==tree
index=validate(tree); old=validate(prior)
assert all(index['aliases'][a]==v for a,v in old['aliases'].items())
attempts=report['attempts']; assert len(attempts)==52 and len({a['request_id'] for a in attempts})==52
assert all(a['status'] in (200,304) and a['outcome']=='response' for a in attempts)
assert sum(bool(a['condition']) for a in attempts)==8
frozen={r['path']:(row,r) for row in json.loads(PAYLOAD.read_bytes())['rows'] for r in row['recipes']}
checks=[]
for item in json.loads(REPORT.read_bytes())['migrated']:
 row,recipe=frozen[item['path']]; rid=index['aliases'][item['alias']]['request_id']; body=tree[index['entries'][rid]['observation']['path']]
 releases=json.loads(body); releases=releases if isinstance(releases,list) else [releases]
 assets={a['browser_download_url'] for r in releases for a in r['assets']}
 original=subprocess.check_output(['git','show',json.loads(PAYLOAD.read_bytes())['source_revision']+':'+item['path']])
 assert hashlib.sha256(original).hexdigest()==recipe['sha256']
 selected=[]
 for key in ('install_selector','update_selector'):
  v=subprocess.run(['sh','-c','APP='+Path(item['path']).name+'\n'+pipeline(row,recipe[key])],input=body,capture_output=True,check=True).stdout.strip()
  assert v.decode() in assets; selected.append(v)
 actual=subprocess.run(['sh','-c',selector_script(Path(item['path']))],input=body,capture_output=True,check=True).stdout.strip()
 assert actual==selected[0]==selected[1]
 checks.append(dict(path=item['path'],asset=actual.decode()))
# Real public HTTP through both production readers, pinned to accepted commit.
alias=checks and json.loads(REPORT.read_bytes())['migrated'][0]['alias']
rid=index['aliases'][alias]['request_id']; expected=tree[index['entries'][rid]['observation']['path']]
body,metadata=lookup(alias,commit=commit); assert body==expected
shell=subprocess.run(['sh','modules/catalog.am',alias,'--commit',commit],env={**os.environ,'AMREPO':'https://raw.githubusercontent.com/mareklangiewicz/AM/main-marek'},capture_output=True,check=True); assert shell.stdout==expected
result=dict(publication=pub,context=ctx,attempts=52,statuses={str(s):sum(a['status']==s for a in attempts) for s in (200,304)},conditional=8,selectors=214,recipes=checks,python_reader=metadata,shell_reader_sha256=hashlib.sha256(shell.stdout).hexdigest(),run=report['run'],tree_bytes=sum(map(len,tree.values())),artifact_digests_verified=True,exact_parent_tree_recomputation=True,preserved_aliases=True)
(D/'acceptance.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('recipes','context','python_reader')},indent=2))
