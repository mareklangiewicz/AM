import hashlib, json, os, pathlib, subprocess, sys, tempfile
ROOT=pathlib.Path('/home/marek/code/shell/AM')
sys.path.insert(0,str(ROOT/'tools/catalog-collector'))
from delivery import read_git_tree
from publication import git
from storage import validate
OUT=pathlib.Path(__file__).resolve().parent
r=json.loads((OUT/'candidate.json').read_text());pin=r['candidate'];parent=r['expected_parent']
with tempfile.TemporaryDirectory(prefix='am-fork-rehearsal-') as tmp:
    p=pathlib.Path(tmp);repo=p/'candidate.git'
    subprocess.run(['git','clone','--bare','--quiet',str(OUT/'candidate.bundle'),str(repo)],check=True,capture_output=True)
    tree=read_git_tree(repo,pin)
    assert git(repo,'rev-parse',pin+'^').decode().strip()==parent
    before=read_git_tree(repo,parent)
    assert {k:v for k,v in tree.items() if k!='lookup.tsv'}==before
    assert all(hashlib.sha256(tree[k]).hexdigest()==v['sha256'] and len(tree[k])==v['bytes'] for k,v in r['files'].items())
    # Explicit development-fork test copy: exactly two owner substitutions.
    original=(ROOT/'modules/catalog.am').read_bytes();fork=(OUT/'fork-reader.sh').read_bytes()
    assert hashlib.sha256(original).hexdigest()==r['production_reader_sha256']
    assert fork==original.replace(b'ivan-hc/AM',b'mareklangiewicz/AM')
    bindir=p/'bin';bindir.mkdir();calls=p/'calls'
    curl=bindir/'curl'
    curl.write_text('#!'+sys.executable+'\n'+'''import json, os, pathlib, re, subprocess, sys
args=sys.argv[1:];url=args[-1]
with open(os.environ['CALLS'],'a') as f: f.write(url+'\\n')
match=re.fullmatch(r'https://raw.githubusercontent.com/mareklangiewicz/AM/([0-9a-f]{40})/(lookup\\.tsv|bodies/[0-9a-f]{64}\\.json)',url)
assert match and match[1]==os.environ['PIN'],url
raw=subprocess.run(['/usr/bin/git','--git-dir='+os.environ['REPO'],'show',match[1]+':'+match[2]],check=True,capture_output=True).stdout
pathlib.Path(args[args.index('--output')+1]).write_bytes(raw)
print('200',end='')
''');curl.chmod(0o755)
    env={**os.environ,'PATH':str(bindir)+':/usr/bin:/bin','CALLS':str(calls),'PIN':pin,'REPO':str(repo)}
    result=subprocess.run(['/bin/sh',str(OUT/'fork-reader.sh'),r['alias'],'--commit',pin],env=env,capture_output=True)
    # Actual wall clock, no fabricated observation validation time. If expired,
    # this preparation refuses; a later public read needs separate exact consent.
    assert result.returncode==0,result.stderr
    assert result.stderr==b'' and result.stdout==tree[r['observation']['path']]
    urls=calls.read_text().splitlines();assert len(urls)==2
    pipeline="sed 's/[()\",{} ]/\\n/g' | grep -oi 'https.*mage$' | grep -vi 'i386\\|i686\\|aarch64\\|arm64\\|armv7l' | head -1"
    def select(raw):
        return subprocess.run(['/bin/sh','-c',pipeline],input=raw,check=True,capture_output=True).stdout.decode().strip()
    selected=select(result.stdout);assert selected and selected==select(before[r['observation']['path']])
    # Rehearse exact-parent, normal fast-forward publication only to a local bare repo.
    remote=p/'remote.git'
    subprocess.run(['git','clone','--bare','--quiet',str(OUT/'prior.bundle'),str(remote)],check=True,capture_output=True)
    git(remote,'update-ref','refs/heads/release-catalog',parent)
    assert git(remote,'rev-parse','refs/heads/release-catalog').decode().strip()==parent
    git(repo,'push',str(remote),pin+':refs/heads/release-catalog')
    assert git(remote,'rev-parse','refs/heads/release-catalog').decode().strip()==pin
    checks=dict(candidate=pin,parent=parent,only_change='add lookup.tsv (4638 bytes)',
       bundle_restored_and_validated=True,local_fast_forward_rehearsal=True,
       production_reader_unchanged=True,fork_copy_exact_owner_substitutions=2,
       transport='local Git curl stub; no HTTP',clock='real wall clock',
       checked_at=subprocess.run(['date','-u','+%FT%TZ'],check=True,capture_output=True,text=True).stdout.strip(),
       calls=urls,exact_body=True,selected_url=selected,stderr='')
    (OUT/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(checks,indent=2))
