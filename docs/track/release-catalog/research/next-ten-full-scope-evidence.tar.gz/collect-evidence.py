import pathlib,json,subprocess,sys,hashlib,time,os,datetime
root=pathlib.Path('/home/marek/code/shell/AM');base=pathlib.Path(__file__).parent;sys.path.insert(0,str(root/'tools/catalog-collector'))
import host_catalog
from publication import bounded
rows,sources=host_catalog.configuration();assert (len(rows),len(sources))==(53,51)
out=base/'fresh-responses';out.mkdir(mode=0o700);start=time.monotonic();used=0;receipts=[]
for rid,name in sources.items():
 assert time.monotonic()-start<300,'transport elapsed cap'
 endpoint=f'repositories/{rid}/releases?per_page=100&page=1'
 body=bounded(['gh','api',endpoint],env=dict(os.environ),cap=host_catalog.RESPONSE_CAP,seconds=35)
 observed=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
 used+=len(body);assert used<=host_catalog.TOTAL_CAP
 data=json.loads(body);assert isinstance(data,list) and len(data)<=100
 (out/(rid+'-releases.json')).write_bytes(body);(out/(rid+'-receipt.txt')).write_text(observed+'\n')
 receipts.append(dict(repository_id=int(rid),repository=name,endpoint='https://api.github.com/'+endpoint,observed_at=observed,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),releases=len(data),assets=sum(len(r['assets']) for r in data)))
 (base/'fresh-response-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print(name,len(data),len(body),flush=True)
(base/'transport-summary.json').write_text(json.dumps(dict(sources=len(sources),bytes=used,elapsed_seconds=time.monotonic()-start),indent=2)+'\n')
