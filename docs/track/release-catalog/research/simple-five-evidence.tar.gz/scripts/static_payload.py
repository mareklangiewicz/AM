import pathlib,json,mmap,subprocess,hashlib,re,os,posixpath,sys
p=pathlib.Path('/home/marek/Documents/Codex/am-catalog-expansion-20261106/simple-five/evidence');payloads=pathlib.Path('/home/marek/Documents/Codex/am-catalog-expansion-20261106/simple-five/payloads')
rows=json.loads((p/'selection.json').read_text())
for row in rows:
 app=row['app'];d=p/app
 if (d/'static.json').exists() or not (d/'payload-receipt.json').exists():continue
 receipt=json.loads((d/'payload-receipt.json').read_text())
 if receipt['status']!='verified':continue
 out={'app':app,'status':'excluded'}
 try:
  asset=payloads/(app+'.AppImage');offset=None
  with asset.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as memory:
   assert memory[:4]==b'\x7fELF' and memory[8:11]==b'AI\x02','not type-2 ELF AppImage'
   assert memory[4]==2 and memory[18:20]==b'\x3e\x00','not ELF64 x86_64 runtime'
   start=0
   for _ in range(100):
    at=memory.find(b'hsqs',start)
    if at<0:break
    result=subprocess.run(['unsquashfs','-s','-o',str(at),str(asset)],capture_output=True,timeout=20)
    if result.returncode==0:offset=at;(d/'superblock.txt').write_bytes(result.stdout);break
    start=at+4
  assert offset is not None,'no valid squashfs offset'
  listing=subprocess.run(['unsquashfs','-cols','1000','-lln','-o',str(offset),str(asset)],capture_output=True,check=True,timeout=60).stdout.decode()
  (d/'listing.txt').write_text(listing);entries={}
  for line in listing.splitlines():
   if ' squashfs-root/' not in line:continue
   rest=line.split(' squashfs-root/',1)[1];name,sep,target=rest.partition(' -> ')
   entries[name]={'mode':line[:10],'link':target if sep else None}
  desktops=[n for n in entries if n.lower().endswith('.desktop')];roots=[n for n in desktops if '/' not in n]
  out.update(offset=offset,desktop_paths=desktops,root_desktops=roots)
  assert len(roots)==1 and not roots[0].startswith('.'),'multiple/missing/hidden root desktops'
  selected=set()
  def resolve(name):
   visited=[]
   for _ in range(10):
    assert name in entries,'missing metadata target '+name
    assert name not in visited,'symlink cycle'
    visited.append(name);selected.add(name);entry=entries[name]
    if entry['link'] is None:
     assert entry['mode'].startswith('-'),'metadata is not regular file';return name,visited
    link=entry['link'];assert not link.startswith('/') and '..' not in pathlib.PurePosixPath(link).parts,'unsafe/unsupported metadata link'
    # Shared runtime moves each metadata link to the root before resolving it.
    name=link.removeprefix('./')
   raise ValueError('metadata link depth')
  desktop,desktop_chain=resolve(roots[0]);icon,icon_chain=resolve('.DirIcon')
  extra_desktops=set(desktops)-set(desktop_chain)
  for extra in extra_desktops: resolve(extra)
  selected.add('AppRun') if 'AppRun' in entries else None
  if entries.get('AppRun',{}).get('link'):
   selected.remove('AppRun') # recorded listing retains target, no launcher execution/extraction required
  dest=d/'metadata'
  assert not dest.exists()
  command=['unsquashfs','-processors','1','-no-progress','-no-xattrs','-o',str(offset),'-d',str(dest),str(asset),*sorted(selected)]
  extracted=subprocess.run(command,capture_output=True,timeout=90)
  (d/'extraction.txt').write_bytes(extracted.stdout+extracted.stderr);assert extracted.returncode==0,'static extraction failed'
  text=(dest/desktop).read_text()
  assert all((dest/name).read_text()==text for name in extra_desktops),'distinct additional desktop entries need review'
  out.update(duplicate_desktops=sorted(extra_desktops))
  out.update(desktop_chain=desktop_chain,icon_chain=icon_chain,desktop_text=text)
  assert not re.search(r'^(Hidden|NoDisplay)\s*=\s*true',text,re.M|re.I),'hidden desktop'
  assert '[Desktop Action ' not in text,'desktop actions need review'
  execs=[line for line in text.splitlines() if line.startswith('Exec=')];assert len(execs)==1,'missing/multiple Exec'
  assert not any(c in execs[0].split('=',1)[1].split(' ',1)[0] for c in ['"',"'",'\\']),'quoted Exec executable needs review'
  assert not re.search(r'["\'\\]--no-sandbox|--no-sandbox["\'\\]',text),'quoted sandbox argument'
  iconbytes=(dest/icon).read_bytes();assert iconbytes,'empty icon'
  out.update(exec=execs[0],icon_bytes=len(iconbytes),icon_sha256=hashlib.sha256(iconbytes).hexdigest(),status='compatible',files=[])
  for name in sorted(selected):
   target=dest/name
   if target.is_symlink():out['files'].append({'path':name,'symlink':os.readlink(target)})
   else:out['files'].append({'path':name,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
 except Exception as e:out['reason']=str(e)
 (d/'static.json').write_text(json.dumps(out,indent=2)+'\n');print(app,out['status'],out.get('reason',out.get('exec')),flush=True)
