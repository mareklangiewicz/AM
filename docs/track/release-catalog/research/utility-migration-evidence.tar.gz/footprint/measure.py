import json,sys,hashlib
from pathlib import Path
sys.path.insert(0,'/src/test/e2e')
from scenarios import InstalledCLI
InstalledCLI.setUpClass()
t=InstalledCLI('test_executable_system_install_icons_standalone_update_and_remove')
t.setUp()
try:
 t.utility_catalog();t.command('-i','7z','arch','c++filt','ld.bfd')
 report={}
 for name in ('7z','arch','c++filt','ld.bfd'):
  root=Path('/opt')/name
  files={}
  for rel in ['AM-updater','recipe.am','remove','.am-installer/'+name]:
   raw=(root/rel).read_bytes();files[rel]=dict(bytes=len(raw),lines=len(raw.splitlines()),sha256=hashlib.sha256(raw).hexdigest())
  report[name]=dict(files=files,total_bytes=sum(x['bytes'] for x in files.values()),total_lines=sum(x['lines'] for x in files.values()))
 modules={}
 for name in ['appimage.am','catalog.am']:
  raw=(Path('/opt/am/modules')/name).read_bytes();modules[name]=dict(bytes=len(raw),lines=len(raw.splitlines()),sha256=hashlib.sha256(raw).hexdigest())
 Path('/out/installed-code.json').write_text(json.dumps(dict(apps=report,shared_modules=modules,scope='Actual system AM install in network-disabled Debian; inert binaries excluded; shared modules counted once; source is fixture e2e-selected/AM/test-source.'),indent=2)+'\n')
finally:
 t.tearDown();t.doCleanups()
