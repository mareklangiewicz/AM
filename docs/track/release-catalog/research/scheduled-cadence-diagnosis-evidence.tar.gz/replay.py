"""Replay captured schedule delivery; no network or time-dependent verdict."""
from pathlib import Path
import json,datetime,base64
p=Path(__file__).resolve().parent
variables={x['name']:x['value'] for x in json.loads((p/'variables.json').read_text())['variables']}
start=datetime.datetime.fromtimestamp(int(variables['CATALOG_SCHEDULE_START']),datetime.timezone.utc)
end=datetime.datetime.fromisoformat(json.loads((p/'captured.json').read_text())['at'])
slot=start.replace(minute=17,second=0,microsecond=0)
if slot<start:slot+=datetime.timedelta(hours=1)
slots=[]
while slot<=end:
 slots.append(slot.isoformat());slot+=datetime.timedelta(hours=1)
s=json.loads((p/'schedule-runs.json').read_text());runs=s['workflow_runs']
assert s['total_count']==len(runs),'Capture must include every run.'
actual=[r for r in runs if datetime.datetime.fromisoformat(r['created_at'].replace('Z','+00:00'))>=start]
report={'start':start.isoformat(),'captured_at':end.isoformat(),'expected_slots':slots,'observed_runs':[{k:r[k] for k in ['id','event','status','conclusion','created_at','run_started_at','updated_at']} for r in actual]}
(p/'cadence-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'Expected {len(slots)} hourly slots; observed {len(actual)} scheduled workflow run(s).')
assert len(actual)>=len(slots)-1,'Sparse schedule event creation (allowing one recent pending slot).'
