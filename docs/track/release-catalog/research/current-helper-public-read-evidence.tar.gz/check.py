import pathlib, tarfile, hashlib, json, subprocess
p=pathlib.Path('/tmp/am-current-helper-read')
repo=pathlib.Path('/home/marek/code/shell/AM')
with tarfile.open(repo/'docs/track/release-catalog/research/fork-shell-public-read-evidence.tar.gz') as t:
 for name in ('lookup.tsv','body.json'):
  assert (p/name).read_bytes()==t.extractfile(name).read()
assert (p/'stdout.json').read_bytes()==(p/'body.json').read_bytes()
assert (p/'stderr').read_bytes()==b''
calls=[json.loads(x) for x in (p/'calls.jsonl').read_text().splitlines()]
assert len(calls)==2 and all(c['http']=='200' and c['returncode']==0 for c in calls)
recipe=(repo/'programs/x86_64/obsidian').read_text()
line=next(x for x in recipe.splitlines() if x.startswith('version=$(printf'))
pipeline=line.split('|',1)[1].rsplit(')',1)[0]
r=subprocess.run(['sh','-c',pipeline],input=(p/'stdout.json').read_bytes(),capture_output=True,check=True)
url=r.stdout.decode().strip()
assert url=='https://github.com/obsidianmd/obsidian-releases/releases/download/v1.14.5/Obsidian-1.14.5.AppImage'
checks={'exact_retained_bytes':True,'stdout_equals_body':True,'empty_stderr':True,'successful_gets':2,'filter_url':url,'files':{n:{'bytes':len((p/n).read_bytes()),'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest()} for n in ('lookup.tsv','body.json')}}
(p/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
