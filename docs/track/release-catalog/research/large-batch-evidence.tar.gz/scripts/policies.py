import pathlib,json,os,sys,shlex,subprocess,shutil,tempfile
from unittest.mock import patch
root=pathlib.Path('/home/marek/code/shell/AM');p=pathlib.Path('/tmp/am-133');sys.path.insert(0,str(root/'tools/catalog-collector'))
import recipe_policy_source as compiler
rows=json.loads((p/'selection.json').read_text())
def declaration(r,module='/opt/am/modules/appimage.am'):
 settings=dict(APP=r['app'],CATALOG_FORMAT='2',CATALOG_RECIPE='x86_64/'+r['app'],CATALOG_ALIAS='https://api.github.com/repos/'+r['requested_repository']+'/releases',CATALOG_REPOSITORY_ID=str(r['repository_id']),CATALOG_REPOSITORY=r['repository'],CATALOG_CHANNEL='any',CATALOG_ASSET_PATTERN=r['pattern'],PACKAGE_KIND='appimage',PACKAGE_LAYOUT='raw',DESKTOP_EXEC='command',DESKTOP_STRIP_NO_SANDBOX='true')
 return '#!/bin/sh\n# AM INSTALL SCRIPT VERSION 3.5\n# AM-CATALOG-RECIPE 1\n# AM-RECIPE-DECLARATION 1\nset -eu\n'+''.join(k+'='+shlex.quote(v)+'\n' for k,v in settings.items())+'\n# shellcheck source=modules/appimage.am\n. "'+module+'"\nam_appimage "$0" "$@"\n'
with tempfile.TemporaryDirectory(prefix='am-133-policy-') as tmp:
 temp=pathlib.Path(tmp);(temp/'modules').mkdir();shutil.copy2(root/'modules/catalog-yaml-policy.am',temp/'modules')
 for r in rows:
  path=temp/'programs/x86_64'/r['app'];path.parent.mkdir(parents=True,exist_ok=True);path.write_text(declaration(r))
 with patch.object(compiler,'ROOT',temp):compiler.generate()
 for r in rows:
  d=p/r['app'];releases=json.loads((d/'releases.json').read_text());facts='';now=r['observed_at'][:19]+'Z'
  for release in releases:
   if release.get('draft'):continue
   for a in release['assets']:
    facts+='\t'.join([str(release['id']),str(a['id']),*map(json.dumps,[now,release['published_at'],release['tag_name'],a['name'],a['browser_download_url']]),json.dumps(release['prerelease'])])+'\n'
  result=subprocess.run(['awk','-f',str(temp/'modules/catalog-yaml-policy.am')],input=facts,text=True,capture_output=True,env={**os.environ,'LC_ALL':'C','AM_YAML_RECIPE':'x86_64/'+r['app'],'AM_YAML_REPOSITORY':str(r['repository_id']),'AM_YAML_PIN':'a'*40,'AM_YAML_NOW':now},timeout=20)
  lines=result.stdout.splitlines();url=lines[-1] if lines else None
  receipt=dict(status='verified' if result.returncode==0 and url==r['old_selected_url'] else 'excluded',old_url=r['old_selected_url'],new_url=url,returncode=result.returncode,stderr=result.stderr)
  (d/'policy.json').write_text(json.dumps(receipt,indent=2)+'\n');print(r['app'],receipt['status'],flush=True)
