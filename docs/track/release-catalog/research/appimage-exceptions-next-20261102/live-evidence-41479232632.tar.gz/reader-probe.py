import json,sys,subprocess,zipfile,hashlib
from pathlib import Path
root=Path('/home/marek/code/shell/AM');sys.path.insert(0,str(root/'tools/catalog-collector'))
from publication import blob,git,REF
from storage import decode,digest
base=Path('/tmp/am-65-acceptance-41479232632')
with zipfile.ZipFile(base/'publication.zip') as archive:pub=json.loads(archive.read('publication.json'))
commit=pub['commit'];repo=base/'git';index=decode(blob(repo,commit,'index.json',2_000_000))
p=root/'docs/track/release-catalog/research';m=json.loads((p/'appimage-exceptions-next-20261102/prepared/migration.json').read_bytes())['migrated']+json.loads((p/'appimage-next-large-batch-20261102/prepared/migration.json').read_bytes())['migrated']
reps={}
for item in m:reps.setdefault(Path(item['path']).parent.name,item['alias'])
for number,alias in enumerate(dict.fromkeys(reps.values())):
 shard=index['shards'][index['aliases'][alias]];selected=decode(blob(repo,commit,shard['path'],shard['bytes']))
 entry=selected['entries'][selected['aliases'][alias]['request_id']]
 expected=entry['observation']
 shell=subprocess.run(['sh',str(root/'modules/catalog.am'),alias,'--commit',commit],env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','AMREPO':'https://raw.githubusercontent.com/mareklangiewicz/AM/main-marek'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=95)
 name=base/f'reader-probe-{number}'
 name.with_suffix('.stderr').write_bytes(shell.stderr)
 result=dict(alias=alias,commit=commit,returncode=shell.returncode,stderr=shell.stderr.decode(errors='replace'),actual_bytes=len(shell.stdout),actual_sha256=digest(shell.stdout),expected=expected,matched=shell.returncode==0 and digest(shell.stdout)==expected['sha256'])
 name.with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
