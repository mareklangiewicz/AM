import hashlib, json, os, pathlib, subprocess, sys, tarfile
ROOT=pathlib.Path('/home/marek/code/shell/AM')
sys.path.insert(0,str(ROOT/'tools/catalog-collector'))
from delivery import read_git_tree
from publication import git, publish_local, REF
from shell_lookup import render
from storage import validate
OUT=pathlib.Path('/tmp/am-shell-validation')
PARENT='d612ff34b492b337fe51128f769ec9d262d0ee86'
SOURCE='605b1cbba25f684fde85cac354ec425535e08ca1'
archive=ROOT/'docs/track/release-catalog/research/catalog-delivery-40533557297-40533858562-evidence.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='f73c29f75e667b8ba1de0f6affdf1d539c13b9f5c6661adf291ac4263aeabf22'
with tarfile.open(archive) as tar:
    (OUT/'prior.bundle').write_bytes(tar.extractfile('catalog-delivery/catalog.bundle').read())
repo=OUT/'candidate.git'
subprocess.run(['git','clone','--bare','--quiet',str(OUT/'prior.bundle'),str(repo)],check=True)
for remote in git(repo,'remote').decode().splitlines(): git(repo,'remote','remove',remote)
prior=read_git_tree(repo,PARENT)
assert 'lookup.tsv' not in prior
index=validate(prior)
tree={**prior,'lookup.tsv':render(index,prior['index.json'])}
validate(tree)
git(repo,'update-ref',REF,PARENT)
candidate=publish_local(repo,tree,PARENT)
assert read_git_tree(repo,candidate)==tree
assert git(repo,'diff-tree','--no-commit-id','--name-status','-r',PARENT,candidate).decode()=='A\tlookup.tsv\n'
git(repo,'bundle','create',str(OUT/'candidate.bundle'),REF)
helper=(ROOT/'modules/catalog.am').read_bytes()
assert helper.count(b'ivan-hc/AM')==2
fork=helper.replace(b'ivan-hc/AM',b'mareklangiewicz/AM')
(OUT/'fork-reader.sh').write_bytes(fork)
alias='https://api.github.com/repos/obsidianmd/obsidian-releases/releases'
rid=index['aliases'][alias]['request_id'];obs=index['entries'][rid]['observation']
report=dict(source_revision=SOURCE,target_repository='mareklangiewicz/AM',target_ref='refs/heads/release-catalog',
    expected_parent=PARENT,candidate=candidate,tree=git(repo,'rev-parse',candidate+'^{tree}').decode().strip(),
    index_sha256=hashlib.sha256(tree['index.json']).hexdigest(),generated_at=index['generated_at'],
    observation=obs,alias=alias,request_id=rid,production_reader_sha256=hashlib.sha256(helper).hexdigest(),
    fork_reader_sha256=hashlib.sha256(fork).hexdigest(),
    files={name:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(tree.items())})
(OUT/'candidate.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
