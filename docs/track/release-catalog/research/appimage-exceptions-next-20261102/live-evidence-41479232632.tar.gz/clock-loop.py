import sys,subprocess,json,time,hashlib
from pathlib import Path
root=Path('/home/marek/code/shell/AM');sys.path.insert(0,str(root/'tools/catalog-collector'))
from consumer import lookup
out=Path('/tmp/am-65-acceptance-41479232632-second')
alias='https://api.github.com/repos/atari800/atari800/releases';commit='e391f35f61a61fde63e9d12ab10b3deb04f2abfb'
for i in range(10):
 before=time.time();expected,_=lookup(alias,commit=commit)
 r=subprocess.run(['sh','-x',str(root/'modules/catalog.am'),alias,'--commit',commit],env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','AMREPO':'https://raw.githubusercontent.com/mareklangiewicz/AM/main-marek'},capture_output=True,timeout=95)
 record=dict(iteration=i,elapsed=time.time()-before,returncode=r.returncode,matched=r.returncode==0 and r.stdout==expected)
 (out/f'clock-loop-{i}.trace').write_bytes(r.stderr);(out/f'clock-loop-{i}.json').write_text(json.dumps(record)+'\n')
 print(json.dumps(record),flush=True)
 if not record['matched']:
  print(r.stderr.decode()[-5000:],flush=True);sys.exit(1)
