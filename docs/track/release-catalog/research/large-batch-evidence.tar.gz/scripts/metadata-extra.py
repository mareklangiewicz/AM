import pathlib,json,subprocess,datetime,hashlib,concurrent.futures
p=pathlib.Path('/tmp/am-133');rows=json.loads((p/'candidates.json').read_text())[-1:]
def fetch(row):
 app=pathlib.Path(row['recipe']).name;repo=row['matches'][0]['parameters'][1];d=p/app;d.mkdir(exist_ok=True)
 result={'app':app,'requested_repository':repo,'provenance':row,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  for name,endpoint in [('repository',f'repos/{repo}'),('releases',f'repos/{repo}/releases?per_page=100')]:
   f=d/(name+'.json')
   r=subprocess.run(['gh','api',endpoint],capture_output=True,timeout=60)
   if r.returncode:raise ValueError(r.stderr.decode()[:300])
   f.write_bytes(r.stdout);result[name+'_sha256']=hashlib.sha256(r.stdout).hexdigest()
  repository=json.loads((d/'repository.json').read_text());releases=json.loads((d/'releases.json').read_text())
  assert repository['full_name'].lower()==repo.lower(), 'repository redirect needs review'
  assert not repository['disabled']
  result.update(repository_id=repository['id'],repository=repository['full_name'],release_count=len(releases))
  import re
  eligible=lambda a: a['name'].lower().endswith('.appimage') and not re.search(r'i386|i686|armhf|aarch64|arm64|armv7l',a['name'],re.I)
  old=[(r,a) for r in releases for a in r['assets'] if eligible(a)]
  assert old,'no eligible direct AppImage asset'
  # Preliminary structured first-response winner; exact textual replay is separate.
  r,a=old[0];result.update(selected_release=r['id'],selected_asset=a,prerelease=r['prerelease'])
  assert 0<a['size']<=400*1024*1024,'payload above per-file cap'
  result['status']='metadata-ready'
 except Exception as e:result.update(status='excluded',reason=str(e))
 (d/'metadata-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(app,result['status'],result.get('reason',str(result.get('selected_asset',{}).get('size'))),flush=True)
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(fetch,rows))
(p/'metadata.json').write_text(json.dumps(json.loads((p/'metadata.json').read_text())+results,indent=2)+'\n')
