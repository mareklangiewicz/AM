import subprocess, pathlib, os, json, datetime, hashlib
p=pathlib.Path('/tmp/am-current-helper-read')
helper=pathlib.Path('/home/marek/code/shell/AM/modules/catalog.am')
cmd=['sh',str(helper),'https://api.github.com/repos/obsidianmd/obsidian-releases/releases','--commit','a0fdd125558c4629a07c7edd0d7f6f7f96b1dcc1']
env={**os.environ,'AMREPO':'https://raw.githubusercontent.com/mareklangiewicz/AM/main-marek','PATH':str(p/'bin')+':/usr/bin:/bin'}
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(cmd,env=env,capture_output=True)
(p/'stdout.json').write_bytes(r.stdout);(p/'stderr').write_bytes(r.stderr)
(p/'result.json').write_text(json.dumps({'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'AMREPO':env['AMREPO'],'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'returncode':r.returncode,'stdout_bytes':len(r.stdout)},indent=2)+'\n')
print((p/'result.json').read_text());print(r.stderr.decode())
