import hashlib, importlib.util, json, os, subprocess, sys, zipfile
from pathlib import Path
from datetime import datetime, timezone
ROOT=Path('/home/marek/code/shell/AM')
OUT=Path('/tmp/am-nov1-review')
sys.path.insert(0,str(ROOT/'tools/catalog-collector'))
from delivery import unpack_artifact, verify_artifact
from storage import validate
from shell_lookup import render
from reader import select, verify_body
def api(endpoint,name):
    raw=(OUT/name).read_bytes() if (OUT/name).exists() else subprocess.check_output(['gh','api','repos/mareklangiewicz/AM/'+endpoint])
    (OUT/name).write_bytes(raw)
    return json.loads(raw)
arts=api('actions/runs/41298051348/artifacts','artifacts.json')['artifacts']
run=api('actions/runs/41298051348','run.json')
assert run['conclusion']=='success' and run['run_attempt']==1
for art in arts:
    name='collection.zip' if art['name'].startswith('restricted-') else 'publication.zip'
    path=OUT/name
    if not path.exists():
        path.write_bytes(subprocess.check_output(['gh','api',f'repos/mareklangiewicz/AM/actions/artifacts/{art["id"]}/zip']))
    assert 'sha256:'+hashlib.sha256(path.read_bytes()).hexdigest()==art['digest']
with zipfile.ZipFile(OUT/'publication.zip') as z:
    pub=json.loads(z.read('publication.json'))
(OUT/'publication.json').write_text(json.dumps(pub,indent=2)+'\n')
parent='a113cd0aca3247111b6ba231f6a30b6477ac2c75'
sha='7b31340a818a226c399130a776c5b03e78241438'
assert pub['parent']==parent and pub['source_revision']==sha and pub['run_id']==str(run['id'])
files=unpack_artifact((OUT/'collection.zip').read_bytes())
report=json.loads(files['report.json'])
ctx=report['context']
assert ctx['previous_publication']==parent and ctx['sha']==sha and ctx['approved_revision']==sha
def tree_at(commit,prefix):
    c=api('git/commits/'+commit,prefix+'-commit.json')
    t=api('git/trees/'+c['tree']['sha']+'?recursive=1',prefix+'-tree.json')
    assert not t['truncated']
    return c,t
pc,pt=tree_at(parent,'prior')
import base64
previous={}
for item in pt['tree']:
    if item['type']=='tree':
        assert item['path']=='bodies'
        continue
    assert item['type']=='blob' and item['mode']=='100644'
    data=api('git/blobs/'+item['sha'],'prior-blob-'+item['sha']+'.json')
    previous[item['path']]=base64.b64decode(data['content'])
tree=verify_artifact(files,ctx,(ROOT/'docs/track/release-catalog/design/staged-manifest.json').read_bytes(),sha,previous)
index=validate(tree)
assert tree['lookup.tsv']==render(index,tree['index.json'])
assert len(report['attempts'])==7 and report['run']['complete']
c,t=tree_at(pub['commit'],'published')
assert [p['sha'] for p in c['parents']]==[parent]
assert len(t['tree'])==len(tree)+1  # bodies directory
blobs=[x for x in t['tree'] if x['type']=='blob']
assert {x['path'] for x in blobs}==set(tree)
for x in blobs:
    raw=tree[x['path']]
    assert x['mode']=='100644' and x['size']==len(raw)
    assert x['sha']==hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
assert api('git/ref/heads/release-catalog','publication-ref.json')['object']['sha']==pub['commit']
assert pub['index_sha256']==hashlib.sha256(tree['index.json']).hexdigest()
assert pub['tree_bytes']==sum(map(len,tree.values()))
assert pub['artifact_digest']==hashlib.sha256((OUT/'collection.zip').read_bytes()).hexdigest()
for alias in json.loads(previous['index.json'])['aliases']:
    assert index['aliases'][alias]['active']
alias='https://api.github.com/repos/ivan-hc/am-utils/releases'
entry,meta=select(tree['index.json'],alias,pub['commit'],now=datetime.now(timezone.utc).isoformat())
body=verify_body(tree[entry['observation']['path']],entry)
assert meta['age_seconds']<=172800
(OUT/'body.json').write_bytes(body)
(OUT/'report.json').write_text(json.dumps({'body_sha256':hashlib.sha256(body).hexdigest()}))
for path,raw in tree.items():
    p=OUT/'candidate'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
summary=dict(publication=pub,reader=meta,attempts=report['attempts'],collection_run=report['run'],tree_bytes=sum(map(len,tree.values())),prior_tree_bytes=sum(map(len,previous.values())),index_bytes=len(tree['index.json']),lookup_bytes=len(tree['lookup.tsv']),artifact_zip_bytes=(OUT/'collection.zip').stat().st_size,verified_at=datetime.now(timezone.utc).isoformat())
(OUT/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print('ACCEPTANCE VERIFIED',pub['commit'])
