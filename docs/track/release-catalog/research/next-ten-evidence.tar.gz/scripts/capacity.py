import pathlib,json,subprocess,sys,time,hashlib,yaml
root=pathlib.Path('/home/marek/code/shell/AM');base=pathlib.Path(__file__).parent;sys.path.insert(0,str(root/'tools/catalog-collector'))
import host_catalog
from bounded import normalize
from retention import refresh
from yaml_publication import candidate_tree,schema_url
from publication import git,publish_tree
pin='daf47edb2b382bc6b7df832b00c43fae12bb73d2';revision=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip();prior=json.loads((root/'docs/track/release-catalog/research/large-batch-publication-deployment.json').read_text())['publication'];batch=json.loads((root/'docs/track/release-catalog/research/next-ten-evidence.json').read_text());selected={r['app']:r for r in batch['candidates'] if r['app'] in batch['converted']}
def blob(path):return subprocess.check_output(['git','-C',str(root),'show',pin+':'+path])
old_apps=yaml.safe_load(blob('apps.yaml'))['apps'];repositories={}
for row in prior['source_documents']:
 rid=str(row['repository_id']);raw=blob('repositories/'+rid+'.yaml');assert hashlib.sha256(raw).hexdigest()==row['yaml_sha256'];repositories[rid]=yaml.safe_load(raw)
start=time.monotonic();measured=[];new_bytes=0
for app,row in selected.items():
 rid=str(row['repository_id']);assert rid not in repositories
 raw=(pathlib.Path('/tmp/am-135')/app/'releases.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==row['releases_sha256'];new_bytes+=len(raw);data=json.loads(raw);observed=row['observed_at'][:19]+'Z'
 seed=dict(format=2,schema=schema_url(revision),repository_id=int(rid),repository=row['repository'])
 doc=refresh(seed,[dict(received_at=observed,releases=normalize(data,100),has_next=len(data)==100,bytes=len(raw),seconds=0)],attempted_at=observed,page_size=100,page_limit=1,max_catalog_bytes=host_catalog.FILE_CAP)
 assert doc['collection']['status']=='ok',app;repositories[rid]=doc
 measured.append(dict(app=app,repository_id=int(rid),releases=len(doc['releases']),assets=sum(len(r['assets']) for r in doc['releases'].values()),history_complete=doc['last_success']['history_complete'],response_bytes=len(raw),response_sha256=row['releases_sha256'],observed_at=observed))
rows,sources=host_catalog.configuration();assert (len(rows),len(sources))==(53,51);apps={r['app']:r['repository_id'] for r in rows};assert all(apps[a]==rid for a,rid in old_apps.items())
tree=candidate_tree(apps,repositories,schema=schema_url(revision),max_file_bytes=host_catalog.FILE_CAP)
repo=base/'catalog.git';repo.mkdir();git(repo,'init','--bare','--quiet','--template=');subprocess.run(['git','-C',str(root),'push',str(repo),pin+':refs/heads/catalog'],capture_output=True,check=True);candidate=publish_tree(repo,tree,pin)
for row in measured:row['yaml_bytes']=len(tree['repositories/'+str(row['repository_id'])+'.yaml'])
old_transport=json.loads((root/'docs/track/release-catalog/research/large-batch-enrollment-replay.json').read_text())['transport']['bytes']
result=dict(prior_pin=pin,candidate_pin=candidate,schema_revision=revision,source_worktree_note='Pending ten-recipe conversion/enrollment; schema_revision is not a claim that uncommitted preparation was in that commit.',recipes=len(apps),repositories=len(repositories),total_yaml_bytes=sum(map(len,tree.values())),largest_yaml_bytes=max(map(len,tree.values())),new_response_bytes=new_bytes,prior_41_source_response_bytes=old_transport,combined_recorded_response_bytes=old_transport+new_bytes,normalization_validation_and_local_publication_seconds=time.monotonic()-start,new_sources=measured,prior_source_hashes_preserved=True,capacity_scope='Exact prior 41 published documents retained unchanged plus ten saved first pages. This is not a fresh 51-source transport/elapsed measurement or current production publication.')
(base/'capacity.json').write_text(json.dumps(result,indent=2)+'\n');(root/'docs/track/release-catalog/research/next-ten-enrollment-capacity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='new_sources'},indent=2))
