import pathlib,sys,json,subprocess,hashlib
p=pathlib.Path('/tmp/am-freshness-live');repo=pathlib.Path('/home/marek/code/shell/AM');sys.path.insert(0,str(repo/'tools/catalog-collector'))
from delivery import read_git_tree
checks=json.loads((p/'checks.json').read_text());tree=read_git_tree(p/'catalog.git',checks['publication']['commit']);out=p/'public'
assert (out/'lookup.tsv').read_bytes()==tree['lookup.tsv']
assert (out/'body.json').read_bytes()==tree[checks['obsidian_observation']['path']]
assert (out/'stdout.json').read_bytes()==(out/'body.json').read_bytes()
assert not (out/'stderr').read_bytes()
calls=[json.loads(x) for x in (out/'calls.jsonl').read_text().splitlines()]
assert len(calls)==2 and all(x['http']=='200' and x['returncode']==0 for x in calls)
line=next(x for x in (repo/'programs/x86_64/obsidian').read_text().splitlines() if x.startswith('version=$(printf'))
filter=line.split('|',1)[1].rsplit(')',1)[0]
r=subprocess.run(['sh','-c',filter],input=(out/'stdout.json').read_bytes(),capture_output=True,check=True)
url=r.stdout.decode().strip();assert url=='https://github.com/obsidianmd/obsidian-releases/releases/download/v1.14.5/Obsidian-1.14.5.AppImage'
checks['public_read']={'successful_gets':2,'exact_tree_bytes':True,'empty_stderr':True,'filter_url':url,'result':json.loads((out/'result.json').read_text())}
(p/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print('Public lookup/body exactly match validated tree; filter unchanged.')
