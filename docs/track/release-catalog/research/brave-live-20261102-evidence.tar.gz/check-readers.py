import os,subprocess,json,hashlib,sys
from pathlib import Path
out=Path('/tmp/am-brave-live-41429379232')
pub=json.loads((out/'publication.json').read_text())
with (out/'shell-body.json').open('wb') as f:
 r=subprocess.run(['sh','/home/marek/code/shell/AM/modules/catalog.am','https://api.github.com/repos/ivan-hc/Brave-appimage/releases','--commit',pub['commit']],env={**os.environ,'AMREPO':'https://raw.githubusercontent.com/mareklangiewicz/AM/main-marek'},cwd=out,stdout=f,stderr=subprocess.PIPE)
assert r.returncode==0,r.stderr
assert (out/'shell-body.json').read_bytes()==(out/'body.json').read_bytes()
repo=out/'history.git'
if not repo.exists(): subprocess.run(['git','init','--bare',str(repo)],check=True,stdout=subprocess.DEVNULL)
subprocess.run(['git','-C',str(repo),'fetch','https://github.com/mareklangiewicz/AM.git','refs/heads/release-catalog'],check=True)
def size(sha):return int(subprocess.check_output(['git','-C',str(repo),'rev-list','--disk-usage','--objects',sha]))
objects=sum(p.stat().st_size for p in (repo/'objects').rglob('*') if p.is_file())
assert objects<=128000000
result={'shell_exact_body':True,'reachable_parent_bytes':size(pub['parent']),'reachable_child_bytes':size(pub['commit']),'object_file_bytes':objects,'commits':int(subprocess.check_output(['git','-C',str(repo),'rev-list','--count',pub['commit']]))}
(out/'readers-history.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
