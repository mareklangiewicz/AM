import pathlib,sys,json,zipfile,subprocess,collections,datetime
p=pathlib.Path(__file__).parent
repo=pathlib.Path(sys.argv[1]);sys.path.insert(0,str(repo/'tools/catalog-collector'))
from delivery import unpack_artifact,verify_artifact,read_git_tree
from storage import validate
def git(*args):return subprocess.check_output(['git','--git-dir='+str(p/'catalog.git'),*args])
source='466e1facce4e66d4b26c06446fc1e524aa0d76df'
raw=(repo/'docs/track/release-catalog/design/staged-manifest.json').read_bytes()
runs=json.loads((p/'runs.json').read_text())['workflow_runs']
children=sorted([r for r in runs if r['name']=='Restricted catalog validation' and r['created_at']>'2026-10-28T00:12:16Z'],key=lambda r:r['created_at'])
results=[]
for r in children:
 rid=str(r['id']);d=p/rid
 files=unpack_artifact((d/f'restricted-catalog-{rid}-1.zip').read_bytes());report=json.loads(files['report.json'])
 with zipfile.ZipFile(d/f'catalog-publication-{rid}-1.zip') as z:pub=json.loads(z.read('publication.json'))
 prior=read_git_tree(p/'catalog.git',pub['parent'])
 tree=verify_artifact(files,report['context'],raw,source,prior)
 assert read_git_tree(p/'catalog.git',pub['commit'])==tree
 assert git('rev-parse',pub['commit']+'^').decode().strip()==pub['parent']
 old=validate(prior);idx=validate(tree)
 for a in report['attempts']:assert a['condition']==old['entries'][a['request_id']]['validators']
 results.append({'run_id':rid,'created_at':r['created_at'],'publication':pub,'collection':report['run'],'statuses':dict(collections.Counter(str(a['status']) for a in report['attempts'])),'validated_at':{k:v['observation']['validated_at'] for k,v in idx['entries'].items()},'tree_recomputed':True,'prior_conditions_verified':True})
assert len(results)==4
assert all(results[i]['publication']['parent']==results[i-1]['publication']['commit'] for i in range(1,len(results)))
head=git('rev-parse','release-catalog').decode().strip()
assert head==results[-1]['publication']['commit']==json.loads((p/'publication-ref.json').read_text())['object']['sha']
assert not any(r['status']!='completed' for r in runs)
assert not any(r['created_at']>='2026-10-29T00:12:16Z' for r in children)
logs='\n'.join(f.read_text() for f in (p/'40826368818').glob('*log.txt'));assert 'inactive_schedule_window' in logs
# Sum all reachable uncompressed Git objects; also record packed history separately.
def objects(rev):
 names=git('rev-list','--objects',rev).splitlines()
 ids=b'\n'.join(n.split()[0] for n in names)+b'\n'
 sizes=subprocess.check_output(['git','--git-dir='+str(p/'catalog.git'),'cat-file','--batch-check=%(objectsize)'],input=ids)
 return {'objects':len(names),'uncompressed_bytes':sum(map(int,sizes.splitlines()))}
before=objects(results[0]['publication']['parent']);after=objects(head)
git('bundle','create',str(p/'catalog.bundle'),'--all')
out={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':source,'runs':results,'requests':sum(r['collection']['attempted'] for r in results),'received_bytes':sum(r['collection']['received_bytes'] for r in results),'history_before':before,'history_after':after,'history_growth_bytes':after['uncompressed_bytes']-before['uncompressed_bytes'],'bundle_bytes':(p/'catalog.bundle').stat().st_size,'post_expiry_refusal_verified':True,'no_post_expiry_child':True,'no_in_flight_runs':True}
(p/'checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='runs'},indent=2))
