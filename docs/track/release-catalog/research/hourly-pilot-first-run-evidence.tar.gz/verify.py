import pathlib,sys,json,zipfile,subprocess,datetime,collections
p=pathlib.Path('/tmp/am-hourly-first-evidence');repo=pathlib.Path('/home/marek/code/shell/AM');sys.path.insert(0,str(repo/'tools/catalog-collector'))
from delivery import unpack_artifact,verify_artifact,read_git_tree
from storage import validate
files=unpack_artifact((p/'restricted-catalog-40640700123-1.zip').read_bytes())
report=json.loads(files['report.json']);context=report['context']
prior=read_git_tree(p/'catalog.git','e8e5cf96295369d90402d7584853eb1d3436463d')
raw=(repo/'docs/track/release-catalog/design/staged-manifest.json').read_bytes()
tree=verify_artifact(files,context,raw,'466e1facce4e66d4b26c06446fc1e524aa0d76df',prior)
with zipfile.ZipFile(p/'catalog-publication-40640700123-1.zip') as z:
 assert z.namelist()==['publication.json'];pub=json.loads(z.read('publication.json'))
assert pub['parent']=='e8e5cf96295369d90402d7584853eb1d3436463d'
assert pub['commit']==json.loads((p/'publication-ref.json').read_text())['object']['sha']
assert read_git_tree(p/'catalog.git',pub['commit'])==tree
parent=subprocess.check_output(['git','--git-dir='+str(p/'catalog.git'),'rev-parse',pub['commit']+'^'],text=True).strip();assert parent==pub['parent']
idx=validate(tree);old=validate(prior)
for a in report['attempts']:assert a['condition']==old['entries'][a['request_id']]['validators']
permissions={}
for job in ('collect','publish'):
 log=(p/(job+'-log.txt')).read_text()
 lines=[x for x in log.splitlines() if 'Contents: ' in x or 'Actions: ' in x or 'Metadata: ' in x]
 permissions[job]=lines
 assert any('Contents: '+('read' if job=='collect' else 'write') in x for x in lines)
 if job=='collect':assert not any('Actions: write' in x or 'Contents: write' in x for x in lines)
 else:assert any('Actions: read' in x for x in lines)
selected=next(e for e in idx['entries'].values() if e['descriptor']['request_id']=='98c8484a8be11cb446c110c6c2a36368618e2015793a4e241ab3aeef7a867205') if False else idx['entries']['98c8484a8be11cb446c110c6c2a36368618e2015793a4e241ab3aeef7a867205']
checks={'publication':pub,'collection':report['run'],'status_counts':dict(collections.Counter(str(a['status']) for a in report['attempts'])),'prior_conditions_verified':6,'tree_recomputation_equal':True,'permission_log_lines':permissions,'obsidian_observation':selected['observation'],'obsidian_fresh_through':(datetime.datetime.fromisoformat(selected['observation']['validated_at'])+datetime.timedelta(days=1)).isoformat()}
(p/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks,indent=2))
