import datetime,json,os,pathlib,subprocess
p=pathlib.Path('/tmp/am-shell-public-read');r=json.loads((p/'candidate.json').read_text())
assert not (p/'curl-calls.jsonl').exists(),'no repeat authorized'
env={**os.environ,'PATH':str(p/'bin')+':/usr/bin:/bin'}
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
result=subprocess.run(['/bin/sh',str(p/'fork-reader.sh'),r['alias'],'--commit',r['candidate']],env=env,capture_output=True)
(p/'stdout.json').write_bytes(result.stdout);(p/'stderr.txt').write_bytes(result.stderr)
(p/'result.json').write_text(json.dumps(dict(started_at=start,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=result.returncode,stdout_bytes=len(result.stdout),stderr_bytes=len(result.stderr)),indent=2)+'\n')
print((p/'result.json').read_text())
