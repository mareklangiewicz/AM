import subprocess,json,pathlib,hashlib
p=pathlib.Path('/tmp/am-freshness-live');base='repos/mareklangiewicz/AM/'
def raw(route):return subprocess.check_output(['gh','api',base+route])
def save(route,name):
 b=raw(route);(p/name).write_bytes(b);return json.loads(b)
r=save('actions/runs/40606441534','run.json');assert r['conclusion']=='success' and r['head_sha']=='3ad023822c4df52e3f69874b21200899bf7d3e82' and r['run_attempt']==1
arts=save('actions/runs/40606441534/artifacts','artifacts.json')
for a in arts['artifacts']:
 assert not a['expired'] and a['size_in_bytes']<=105000000
 b=raw('actions/artifacts/'+str(a['id'])+'/zip')
 assert 'sha256:'+hashlib.sha256(b).hexdigest()==a['digest']
 (p/(a['name']+'.zip')).write_bytes(b)
jobs=save('actions/runs/40606441534/jobs','jobs.json')
for j in jobs['jobs']:
 assert j['conclusion']=='success'
 (p/(j['name']+'-log.txt')).write_bytes(raw('actions/jobs/'+str(j['id'])+'/logs'))
c=save('git/ref/heads/release-catalog','publication-ref.json')
repo=p/'catalog.git'
subprocess.run(['git','init','--bare',str(repo)],check=True,capture_output=True)
subprocess.run(['git','--git-dir='+str(repo),'fetch','https://github.com/mareklangiewicz/AM.git','refs/heads/release-catalog:refs/heads/release-catalog'],check=True,capture_output=True)
assert subprocess.check_output(['git','--git-dir='+str(repo),'rev-parse','release-catalog'],text=True).strip()==c['object']['sha']
subprocess.run(['git','--git-dir='+str(repo),'bundle','create',str(p/'catalog.bundle'),'--all'],check=True,capture_output=True)
print(json.dumps({'run':r['id'],'conclusion':r['conclusion'],'commit':c['object']['sha'],'artifacts':len(arts['artifacts'])}))
