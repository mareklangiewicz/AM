import subprocess,json,pathlib,hashlib
p=pathlib.Path(__file__).parent
base='repos/mareklangiewicz/AM/'
def raw(route): return subprocess.check_output(['gh','api',(base+route).rstrip('/')])
def save(route,name):
 b=raw(route); (p/name).write_bytes(b); return json.loads(b)
save('actions/workflows','workflows.json'); save('actions/variables','variables.json'); save('','repository.json')
runs=save('actions/runs?per_page=100','runs.json')
assert runs['total_count']<=100
for r in runs['workflow_runs']:
 if r['created_at']<'2026-10-28T00:12:16Z': continue
 rid=str(r['id']); d=p/rid;d.mkdir(exist_ok=True)
 save('actions/runs/'+rid,rid+'/run.json')
 jobs=save('actions/runs/'+rid+'/jobs',rid+'/jobs.json')
 for j in jobs['jobs']:
  (d/(str(j['id'])+'-log.txt')).write_bytes(raw('actions/jobs/'+str(j['id'])+'/logs'))
 arts=save('actions/runs/'+rid+'/artifacts',rid+'/artifacts.json')
 for a in arts['artifacts']:
  assert not a['expired'] and a['size_in_bytes']<105000000
  b=raw('actions/artifacts/'+str(a['id'])+'/zip')
  assert 'sha256:'+hashlib.sha256(b).hexdigest()==a['digest']
  (d/(a['name']+'.zip')).write_bytes(b)
 print(rid,r['conclusion'],flush=True)
save('git/ref/heads/release-catalog','publication-ref.json')
save('git/ref/heads/main-marek','source-ref.json')
