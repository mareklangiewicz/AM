import sys,json,shlex,datetime
from pathlib import Path
from unittest.mock import patch
repo=Path.cwd()
sys.path.insert(0,str(repo/'tools/recipe-reconstruction'))
import test_candidate_runtime as harness
root=Path(sys.argv[1]); rows=json.loads((root/'receipts.json').read_text())
patterns={'20x':'^20x-linux-x86_64[.]AppImage$','2fac':'^2FAC_[0-9]+([.][0-9]+)*_amd64[.]AppImage$'}
checks=[]
for app in patterns:
 source=next(r for r in rows if r['app']==app and r['kind']=='releases')
 identity=next(r['repository'] for r in rows if r['app']==app and r['kind']=='repository')
 harness.NOW=datetime.datetime.fromisoformat(source['observed_at']).strftime('%Y-%m-%dT%H:%M:%SZ')
 raw=json.loads((root/(app+'-releases.json')).read_text())
 releases=[dict(id=str(r['id']),tag_name=r['tag_name'],published_at=r['published_at'],prerelease=r['prerelease'],assets=[dict(id=str(a['id']),name=a['name'],browser_download_url=a['browser_download_url']) for a in r['assets']]) for r in source['releases']]
 h=harness.CandidateRuntime();h.setUp()
 try:
  old=h.old_select(app,raw)
  path=h.policy_root/'programs/x86_64'/app
  path.write_text('\n'.join('CATALOG_REPOSITORY_ID='+str(identity['id']) if line.startswith('CATALOG_REPOSITORY_ID=') else 'CATALOG_REPOSITORY='+identity['full_name'] if line.startswith('CATALOG_REPOSITORY=') else line for line in path.read_text().splitlines())+'\n')
  with patch.object(harness.compiler,'ROOT',h.policy_root):harness.compiler.generate()
  generic=h.new_select(app,releases,AM_YAML_REPOSITORY=str(identity['id']))
  path.write_text('\n'.join('CATALOG_ASSET_PATTERN='+shlex.quote(patterns[app]) if line.startswith('CATALOG_ASSET_PATTERN=') else line for line in path.read_text().splitlines())+'\n')
  with patch.object(harness.compiler,'ROOT',h.policy_root):harness.compiler.generate()
  narrow=h.new_select(app,releases,AM_YAML_REPOSITORY=str(identity['id']))
  assert old and narrow==old
  checks.append(dict(app=app,repository_id=identity['id'],repository=identity['full_name'],observed_at=harness.NOW,old_selector_used_full_response=True,old_selector_url=old,generic_declaration_url=generic,narrow_pattern=patterns[app],narrow_declaration_url=narrow,old_equals_generic=old==generic,old_equals_narrow=old==narrow,release_count=len(releases),asset_count=sum(len(r['assets']) for r in releases),matching_assets=[dict(release_id=r['id'],asset_id=a['id'],name=a['name'],url=a['browser_download_url']) for r in releases for a in r['assets'] if a['browser_download_url']==narrow]))
 finally:h.doCleanups()
(root/'selection-comparison.json').write_text(json.dumps(checks,indent=2)+'\n')
for c in checks:print(c['app'],c['repository_id'],'generic_same',c['old_equals_generic'],'narrow_same',c['old_equals_narrow'])
