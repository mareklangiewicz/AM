import pathlib,json,hashlib,shlex,tarfile,subprocess,datetime
root=pathlib.Path('/home/marek/code/shell/AM');p=pathlib.Path('/tmp/am-133');research=root/'docs/track/release-catalog/research';rows=json.loads((p/'selection.json').read_text());ready=[];exclusions=[]
for r in rows:
 d=p/r['app'];reason=None
 for filename,key,value in [('payload-receipt.json','status','verified'),('static.json','status','compatible'),('policy.json','status','verified')]:
  if not (d/filename).exists():reason='missing '+filename;break
  result=json.loads((d/filename).read_text())
  if result[key]!=value:reason=result.get('reason',filename+' '+result[key]);break
 if reason:exclusions.append(dict(app=r['app'],reason=reason))
 else:ready.append(r)
assert len(ready)==20, (len(ready),exclusions)
# Validate every before-image before replacing any source.
for r in ready:
 path=root/r['provenance']['recipe'];assert hashlib.sha256(path.read_bytes()).hexdigest()==r['provenance']['source_sha256'];assert r['strip_no_sandbox']
for r in ready:
 settings=dict(APP=r['app'],CATALOG_FORMAT='2',CATALOG_RECIPE='x86_64/'+r['app'],CATALOG_ALIAS='https://api.github.com/repos/'+r['requested_repository']+'/releases',CATALOG_REPOSITORY_ID=str(r['repository_id']),CATALOG_REPOSITORY=r['repository'],CATALOG_CHANNEL='any',CATALOG_ASSET_PATTERN=r['pattern'],PACKAGE_KIND='appimage',PACKAGE_LAYOUT='raw',DESKTOP_EXEC='command',DESKTOP_STRIP_NO_SANDBOX='true')
 source='#!/bin/sh\n# AM INSTALL SCRIPT VERSION 3.5\n# AM-CATALOG-RECIPE 1\n# AM-RECIPE-DECLARATION 1\nset -eu\n'+''.join(k+'='+shlex.quote(v)+'\n' for k,v in settings.items())+'\n# shellcheck source=modules/appimage.am\n. "/opt/am/modules/appimage.am"\nam_appimage "$0" "$@"\n'
 (root/r['provenance']['recipe']).write_text(source)
subprocess.run(['python3','tools/catalog-collector/recipe_policy_source.py'],cwd=root,check=True)
# Portable saved primary observations, listings, inert metadata and acquisition code.
archive=research/'large-batch-evidence.tar.gz';manifest={}
with tarfile.open(archive,'w:gz',dereference=False) as tar:
 for r in rows:
  d=p/r['app']
  for path in sorted(d.rglob('*')):
   if path.is_dir():continue
   name=path.relative_to(p).as_posix()
   if path.is_symlink():manifest[name]={'symlink':str(path.readlink())}
   else:manifest[name]={'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
   tar.add(path,arcname=name,recursive=False)
 for name in ['metadata.py','metadata-extra.py','prepare.py','acquire.py','acquire-extra.py','static_payload.py','policies.py','convert.py','screening.json','candidates.json']:
  path=p/name;tar.add(path,arcname='scripts/'+name,recursive=False)
receipt=dict(ticket=133,source_before='971abc3d1',observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),evidence_archive=archive.name,evidence_archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),converted=[r['app'] for r in ready],candidates=rows,exclusions=exclusions,manifest=manifest,collection_enrollment_changed=False,total_acquired_payload_bytes=sum(f.stat().st_size for f in pathlib.Path('/home/marek/Documents/Codex/am-large-batch-20261106').glob('*.AppImage')),total_verified_payload_bytes=sum(json.loads((p/r['app']/'payload-receipt.json').read_text()).get('bytes',0) for r in rows),policy='publication descending, release numeric ID descending, asset bytewise name then ID; any channel; retained release set; direct acquisition; URL version; ordinary 48-hour freshness and explicit stale acceptance; literal desktop sandbox flag stripping')
(research/'large-batch-evidence.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Converted:',', '.join(receipt['converted']));print('Excluded:',exclusions);print('Evidence bytes:',archive.stat().st_size)
