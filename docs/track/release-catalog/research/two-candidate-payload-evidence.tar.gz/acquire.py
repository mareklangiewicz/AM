import pathlib,json,urllib.request,hashlib,datetime
p=pathlib.Path('/tmp/am-129-evidence'); total=0; receipts=[]
for app,aid,size in [('20x',688278008,437228965),('2fac',594778867,83560952)]:
 data=json.loads((p/'prior'/f'{app}-releases.json').read_text())
 matches=[(r,a) for r in data for a in r['assets'] if a['id']==aid]
 assert len(matches)==1
 r,a=matches[0]; assert a['size']==size
 assert total+size<=550*1024*1024
 out=p/f'{app}.AppImage'; h=hashlib.sha256(); count=0
 with urllib.request.urlopen(a['browser_download_url'],timeout=45) as response, out.open('wb') as f:
  assert response.status==200
  if response.headers.get('Content-Length'): assert int(response.headers['Content-Length'])==size
  while True:
   b=response.read(min(1024*1024,size-count+1))
   if not b:break
   count+=len(b); assert count<=size
   f.write(b);h.update(b)
 assert count==size
 assert 'sha256:'+h.hexdigest()==a['digest']
 total+=count
 receipts.append(dict(app=app,asset_id=aid,release_id=r['id'],url=a['browser_download_url'],bytes=count,sha256=h.hexdigest(),published_digest=a['digest'],observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
 (p/'payload-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print(app,count,h.hexdigest(),flush=True)
